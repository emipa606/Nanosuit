﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Nanosuit
{
    class NanosuitMod : Mod
    {
        public static NanosuitSettings settings;
        public NanosuitMod(ModContentPack pack) : base(pack)
        {
            settings = GetSettings<NanosuitSettings>();
        }
        public override void DoSettingsWindowContents(Rect inRect)
        {
            base.DoSettingsWindowContents(inRect);
            settings.DoSettingsWindowContents(inRect);
        }
        public override string SettingsCategory()
        {
            return "Nanosuit";
        }

        public override void WriteSettings()
        {
            base.WriteSettings();
        }
    }


}